<?php

/**
 * An SMTP self test for the SMTPPro Magento extension
 *
 * @author Ashley Schroder (aschroder.com)
 */


class Aschroder_SMTPPro_IndexController
	extends Mage_Adminhtml_Controller_Action {

	public function indexAction() {

		Mage::log("Running SMTP Pro Self Test");
		
		#report development mode for debugging
		$dev = Mage::helper('smtppro')->getDevelopmentMode();
		Mage::log("Development mode: " . $dev);
		
		$success = true;
		$websiteModel = Mage::app()->getWebsite($this->getRequest()->getParam('website'));

		$msg = "ASchroder.com SMTP Pro Self-test results";
		
		$msg = $msg . "<br/>Testing outbound connectivity to Server:";
		Mage::log("Raw connection test....");
		
		
		$googleapps = Mage::helper('smtppro')->getGoogleApps();
		
		if($googleapps) {
			$msg = $msg . "<br/>Using Google Apps/Gmail configuration options";
			$host = "smtp.gmail.com";
			$port = 587;
		} else {
			$msg = $msg . "<br/>Using SMTP configuration options";
			$host = Mage::getStoreConfig('system/smtpsettings/host', $websiteModel->getId());
			$port = Mage::getStoreConfig('system/smtpsettings/port', $websiteModel->getId());
		}
		

		$fp = false;
		
		try {
			$fp = fsockopen($host, $port, $errno, $errstr, 15);
		} catch ( Exception $e) {
			// An error will be reported below.
		}

		Mage::log("Complete");

		if (!$fp) {
			$success = false;
			$msg = $msg . "<br/>Failed to connect to SMTP server. Reason: " . $errstr . "(" . $errno . ")";
		 	$msg = $msg . "<br/> This extension requires an outbound SMTP connection on port: " . $port;
		} else {
			$msg = $msg . "<br/> Connection to Host SMTP server successful.";
			fclose($fp);
		}

		$to = Mage::getStoreConfig('contacts/email/recipient_email', $websiteModel->getId());

		$mail = new Zend_Mail();

	        $mail->addTo($to)
        		->setSubject("Test Email From ASchroder.com SMTP Pro Module")
	            	->setBodyText("Hi,\n\n" .
       	                 "If you are seeing this email then your " .
       	                 "SMTP Pro settings are correct! \n\n" .
       	                 "For more information about this extension and " .
       	                 "tips for using it please visit ASchroder.com.\n\n" .
       	                 "Regards,\nAshley");

		if ($dev != "supress") {
			
			Mage::log("Actual email sending test....");
			$msg = $msg . "<br/> Sending test email to your contact form address " . $to . ":";
			
	        try {
				$transport = Mage::helper('smtppro')->getTransport($websiteModel->getId());
				
				$mail->send($transport);
				$msg = $msg . "<br/> Test email was sent successfully.";
				Mage::log("Test email was sent successfully");
				
	    	} catch (Exception $e) {
				$success = false;
				$msg = $msg . "<br/> Unable to send test email. Exception message was: " . $e->getMessage() . "...";
			 	$msg = $msg . "<br/> Please check and double check your username and password.";
				Mage::log("Test email was not sent successfully: " . $e->getMessage());
	    	}
		} else {
			Mage::log("Not sending test email - all mails currently supressed");
			$msg = $msg . "<br/> No test email sent, development mode is set to supress all emails.";
		}
		
		Mage::log("Complete");

		if($success) {
			$msg = $msg . "<br/> Testing complete, if you are still experiencing difficulties please visit  <a target='_blank' href='http://aschroder.com'>ASchroder.com</a> to contact me.";
			Mage::getSingleton('adminhtml/session')->addSuccess($msg);
		} else {
			$msg = $msg . "<br/> Testing failed,  please review the reported problems and if you need further help visit  <a target='_blank' href='http://aschroder.com'>ASchroder.com</a> to contact me.";
			Mage::getSingleton('adminhtml/session')->addError($msg);
		}
 
		$this->_redirectReferer();
	}

} 
