$(function () {
	$('.content-item img').hover(function() {
		$(this).fadeTo("fast", 0.7);
	}, function() {
		$(this).fadeTo("fast", 1);
	});
});
$(function () {
	$('#submit').hover(function() {
		$(this).fadeTo("fast", 0.7);
	}, function() {
		$(this).fadeTo("fast", 1);
	});
});
$(function () {
	$('#menu li').hover(function() {
		$(this).fadeTo("fast", 0.7);
	}, function() {
		$(this).fadeTo("fast", 1);
	});
});
$(function () {
	$('#logo').hover(function() {
		$(this).fadeTo("fast", 0.7);
	}, function() {
		$(this).fadeTo("fast", 1);
	});
});
$(function () {
	$('a').hover(function() {
		$(this).fadeTo("fast", 0.7);
	}, function() {
		$(this).fadeTo("fast", 1);
	});
});