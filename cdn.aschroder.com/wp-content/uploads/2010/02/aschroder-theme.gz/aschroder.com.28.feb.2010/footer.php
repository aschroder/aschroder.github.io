


<div id="footer">
<div class="wrapper">
&copy; <?php echo date('Y'); ?>, <?php bloginfo('name'); ?> + <a href="#" target="_blank">Homebrewed Theme</a> + <a rel="nofollow" href="http://www.wordpress.org" target="_blank">Wordpress</a>

<?php wp_footer(); ?>
</div>
</div> 


 
</body>
</html>