<?php get_header(); ?>

			<div id="main" class="clearfloat">
	<div id="content" class="clearfloat">
	
	<?php
	if (have_posts()) : while (have_posts()) : the_post(); ?>
	<div class="post" id="post-<?php the_ID(); ?>">

  	<h2><?php if ($section_title) {echo $section_title;} else { the_title(); } ?></h2>
		<div class="entry" id="content">
			<?php the_content(); ?>
			 <?php edit_post_link('Edit post', '<p>', '</p>'); ?>
			</div><!--END ENTRY-->
		
		</div><!--END POST-->
		
		
	<?php endwhile; endif; ?>
	
</div>

<?php get_sidebar(); ?>
</div><!--END MAIN-->



</div><!--END WRAPPER-->
</div><!--END TOP-->

<div id="middle">
<div class="wrapper clearfloat">

<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar-home') ) : ?>

<?php include (TEMPLATEPATH . "/tag-cloud.php"); ?>

<?php include (TEMPLATEPATH . "/recent-comments.php"); ?>


<?php endif; ?>

</div><!--END WRAPPER-->
</div><!--END MIDDLE-->

<?php get_footer(); ?>
