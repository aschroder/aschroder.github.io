<div id="sidebar">

<h3>My Profile</h3>
<div class="module">
<?php query_posts('showposts=1'); ?>
<?php while (have_posts()) : the_post(); ?>
<?php echo get_avatar( get_the_author_email(), '56' ); ?>

<p><?php the_author_description(); ?></p>
<?php endwhile; ?>
</div>

<ul>

<?php if ( !function_exists('dynamic_sidebar')
|| !dynamic_sidebar('sidebar-interior') ) : ?>



<?php endif; ?>


</ul>

</div>

