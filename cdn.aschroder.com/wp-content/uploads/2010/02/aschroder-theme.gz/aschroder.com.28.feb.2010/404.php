<?php get_header(); ?>

<div id="main" class="clearfloat">

<div id="content">
<h3>Error 404: Page Not Found</h3>
</div>

<?php get_sidebar(); ?>
 </div>
  
  
  </div><!--END WRAPPER-->
</div><!--END TOP-->
<?php get_footer(); ?>