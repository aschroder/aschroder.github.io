<div class="widget" id="tagcloud">
<h3>Popular Topics</h3>
<?php wp_tag_cloud('smallest=.8&largest=1.8&orderby=count&order=DESC&number=45&unit=em'); ?>
</div>