<?php get_header(); ?>

<div class="clearfloat">
<div id="content">

<?php
	$postcount = 0;
	$page = (get_query_var('paged')) ? get_query_var('paged') : 1;
	query_posts( 'paged=$page&showposts=5' );
	if (have_posts()) { while (have_posts()) { the_post(); 
		if( $postcount == 0 ) { 
		//GETS LATEST POST
?>
			
		<div class="entry normal">
			
			<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
					
			<p class="postmetadata">Posted <em>by</em> <?php the_author(); ?> <em>on</em> <?php the_time('M j, Y') ?> &bull; <span class="commentcount">(<a href="<?php the_permalink(); ?>#commentarea"><?php comments_number('0', '1', '%'); ?></a>)</span></p>
				
			 <?php the_content('Read more...'); //the_excerpt(); ?>

                </div><!--END LATEST-->

<?php
		} elseif( $postcount > 0 && $postcount <= 8 ) { 
		//GETS MORE EXCERPTS
?>

<div class="entry normal">
			
			<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
					
			<p class="postmetadata">Posted <em>by</em> <?php the_author(); ?> <em>on</em> <?php the_time('M j, Y') ?> &bull; <span class="commentcount">(<a href="<?php the_permalink(); ?>#commentarea"><?php comments_number('0', '1', '%'); ?></a>)</span></p>
				
			 <?php the_content('Read more...'); //the_excerpt(); ?>

                </div><!--END LATEST-->

<?php
		}
		$postcount ++;
		// close the loop
		} 
	}
?>

<a href="<?php bloginfo('url'); ?>/archives" class="button">&laquo;Older Posts</a>
</div><!--END CONTENT-->




<?php get_sidebar(); ?>

</div><!--END FLOATS-->
</div><!--END TOP-->
</div><!--END WRAPPER-->

<div id="middle">
<div class="wrapper clearfloat">

<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar-home') ) : ?>

<?php include (TEMPLATEPATH . "/tag-cloud.php"); ?>

<?php include (TEMPLATEPATH . "/recent-comments.php"); ?>


<?php endif; ?>

</div><!--END WRAPPER-->
</div><!--END MIDDLE-->

<?php get_footer(); ?>
